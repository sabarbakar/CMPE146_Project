#include "ssp2_lab.h"
#include "lpc40xx.h"
#include <stdint.h>
void ssp2__init(uint32_t max_clock_mhz) {
  LPC_SC->PCONP |= (1 << 20);
  LPC_SSP2->CR0 = 7;
  LPC_SSP2->CR1 = (1 << 1);
  const uint32_t clk_size = (clock__get_core_clock_hz() / (1000 * 1000)) / max_clock_mhz;
  LPC_SSP2->CPSR = clk_size;
}

uint8_t ssp2_lab__exchange_byte(uint8_t data_out) {
  LPC_SSP2->DR = data_out;
  const uint32_t Busy = (1 << 4);
  while (LPC_SSP2->SR & Busy) {
    ;
  }
  return LPC_SSP2->DR;
}
